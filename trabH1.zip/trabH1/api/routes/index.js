var express = require('express');
var router = express.Router();
const axios = require('axios');
const translatte = require('translatte');

/* GET home page. */
router.get('/get-tweets-from-query', async function (req, res, next) {
  const q = req.query.query;
  const trad = (await translatte(q, { from: 'pt', to: 'en' })).text;
  const tweets = (await axios.get(`https://api.twitter.com/2/tweets/search/recent?query=${trad}`, {
    headers: {
      'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAAJ3jdwEAAAAA1i0JvrkDOk9RncUApYmplRAtjWE%3DuyD3Jjw4qidoXggHcoEH5RKHP5b4D8H3y6Wq1DmD5oytxdoOjF'
    }
  })).data.data;

  const final_data_promises = tweets.map(async ({ text }) => {
    _text = text.split(":");
    text = _text.length == 2 ? _text[1] : _text[0];
    text = text.replace(/[^\w\s]/gi, '')
    try {
      const response = (await axios.post(
        'https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/db7b5e4d-3af4-45ef-8f0c-4edab6f2ce25/v1/analyze',
        {
          'text': text,
          'features': {
            'sentiment': {},
            'keywords': {
              'emotion': true
            }
          }
        },
        {
          params: {
            'version': '2019-07-12'
          },
          headers: {
            'Content-Type': 'application/json'
          },
          auth: {
            username: 'apikey',
            password: 'Sk7Gye2jlynKVgqpmIGLp2vjRA6e4ZZOroCxSPmofUBE'
          }
        }
      )).data;
      let score = response.sentiment.document.score;
      let label = (await translatte(response.sentiment.document.label, { from: 'en', to: 'pt' })).text;
      let tweet_em_portugues = (await translatte(text, { from: 'en', to: 'pt' })).text;
      let obj = {
        tweet_original: text,
        tweet: tweet_em_portugues,
        sentimento: label,
        porcentagem: Math.abs(score) * 100
      }
      return obj;
    } catch (error) {
      return {};
    }
  });
  const final_data = await Promise.all(final_data_promises);
  res.send([...new Set(final_data)]);
});

module.exports = router;

