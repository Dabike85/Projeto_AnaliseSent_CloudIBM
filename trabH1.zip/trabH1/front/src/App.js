import React from 'react';
import SentimentAnalysis from './services/sentiment_analysis';
// import LoadingBar from 'react-top-loading-bar';

const App = () => {
  const [fraseParaAnalisar, setFraseParaAnalisar] = React.useState("");
  const [data, setData] = React.useState(null);
  const [carregando, setCarregando] = React.useState(true);
  const [mediaPositiva, setMediaPositiva] = React.useState(false);

  const getData = async () => {
    const response = await SentimentAnalysis.analyse(fraseParaAnalisar);
    const media = response.reduce(function (a, b) {
      return a + b["porcentagem"];
    }, 0);
    setData(data);
    setMediaPositiva(media >= 60);
    return response;
  }

  const analisarFrase = async () => {
    setCarregando(true);
    await getData();
    setCarregando(false);
  }

  return (
    <div style={{ display: "flex", flex: 1, flexDirection: "column", backgroundColor: mediaPositiva ? "green" : "red" }}>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <h2>Analisador de tweets</h2>
      </div>

      <div style={{ display: "flex", flex: 1, flexDirection: "row", justifyContent: "center" }}>
        <input
          placeholder='Digite a frase que deseja analisar ...'
          onChange={(evt) => setFraseParaAnalisar(evt.target.value)}
          type="text"
          style={{
            width: '50%',
            pading: 10,
            marginRight: 10,
            backgroundColor: "white"
          }}
        />
        <button
          onClick={analisarFrase}
          style={{
            borderRadius: 5,
            backgroundColor: "blue",
            borderColor: "darkblue",
            padding: 10
          }}
        >
          Analisar
        </button>
      </div>

      <div style={{ maxHeight: 200, minHeight: 200, overflowY: "scroll" }}>
        {
          carregando ?
            <div style={{ display: "flex", justifyContent: "center" }}>
              <p>
                Carregando ...
              </p>
            </div>
            :
            data.length != 0 ?
              data.map(d => (
                <div style={{ display: "flex", flexDirection: "column" }}>
                  <h6>{d.tweet}</h6>
                  <p>{d.tweet_original}</p>
                  <p>{d.porcentagem}</p>
                </div>
              )) :
              <div>
                <p>
                  Nenhum dado encontrado.
                </p>
              </div>
        }
      </div>
    </div>
  );
}

export default App;
