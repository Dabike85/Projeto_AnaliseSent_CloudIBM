import axios from "axios";

const api = axios.create({
  baseURL: `http://localhost:9000`
});

const SentimentAnalysis = {
  analyse: async function (frase) {
    const response = await api.get(`/get-tweets-from-query?query=${frase}`);
    return response;
  }
}

export default SentimentAnalysis;